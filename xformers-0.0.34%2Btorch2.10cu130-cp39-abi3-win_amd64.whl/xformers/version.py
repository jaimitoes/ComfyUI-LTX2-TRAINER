# noqa: C801
__version__ = "0.0.34+5f95c7af.d20260113"
